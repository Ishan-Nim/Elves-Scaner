
const keys = {
  shodan: process.env.REACT_APP_SHODAN_API_KEY,
  whoApi: process.env.REACT_APP_WHO_API_KEY,
};

export default keys;
