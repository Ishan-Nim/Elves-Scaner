declare module 'react-simple-maps';
